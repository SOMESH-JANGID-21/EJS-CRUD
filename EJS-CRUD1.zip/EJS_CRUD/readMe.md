# commands to create project
1: To create package.json `npm init -y` 
2: To install node packages `npm install --save express mongoose ejs cors cookie-parser`